/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package changemaker;

/**
 *
 * @author as.kaseorg
 */

import java.util.Scanner;

public class ChangeMaker
{
    public static void main(String[] args)
    {
        int amount;
        int originalAmount;
        int dollars;
        int halfdollars;
        int quarters;
        int dimes;
        int nickels;
        int pennies;

        System.out.println("Enter a whole number from 1 to 1000.");
        System.out.println("I will find a combination of coins");
        System.out.println("that equals that amount of change.");

        Scanner keyboard = new Scanner(System.in);
        amount = keyboard.nextInt( );

        originalAmount = amount;
        dollars = amount / 100;
        halfdollars = amount / 50;
        quarters = amount / 25;
        amount = amount % 25;
        dimes = amount / 10;
        amount = amount % 10;
        nickels = amount / 5;
        amount = amount % 5;
        pennies = amount;

        System.out.println(originalAmount +
                           " cents in coins can be given as:");
        System.out.println(dollars + " dollars");
        System.out.println(halfdollars + " halfdollars");
        System.out.println(quarters + " quarters");
        System.out.println(dimes + " dimes");
        System.out.println(nickels + " nickels and");
        System.out.println(pennies + " pennies");
    }
}