/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package changemaker;

import java.util.Scanner;

/**
 *
 * @author as.kaseorg
 */
public class Numbers1_4P127 
{
    public static void main(String[] args)
    {
        /* TODO Include a main line and all the code necessary for numbers 1-4 on p 127
        Question 4: a) 24    b) 19    c) 15
        Question 1: I tried my best here, and I think I have the basic structure
        but it doesn't work. If you can tell me what to fix, I can resubmit 
        it as soon as possible. */

       Scanner keyboard = new Scanner(System.in);
       System.out.println("Type your floating-point value here.");
       float x = keyboard.nextFloat();
       float y = 1.0F/x;
       float product = x * y;
       System.out.println("x = " + x);
       System.out.println("y = " + y);
       System.out.println("Product of x and y = " + product);
       System.out.println("Subtract 1 = " + product);
   
   }
}
